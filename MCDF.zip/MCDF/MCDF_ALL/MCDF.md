## 测试MCDF
0-250ns测试**control_register**数据写入读出
300-500ns发送第一次，通道1发送，4个数据